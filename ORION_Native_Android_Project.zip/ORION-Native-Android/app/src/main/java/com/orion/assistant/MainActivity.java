package com.orion.assistant;
import android.app.*; import android.os.*; import android.content.*; import android.speech.*; import android.speech.tts.TextToSpeech; import android.view.*; import android.widget.*; import android.graphics.Color; import java.util.*;
public class MainActivity extends Activity {
 TextView output; EditText input; TextToSpeech tts; SharedPreferences prefs; static final int SPEECH=42;
 public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("orion",0); LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,28,24,20);root.setBackgroundColor(Color.rgb(9,16,32));
 TextView title=new TextView(this);title.setText("ORION");title.setTextSize(32);title.setTextColor(Color.rgb(94,211,255));title.setGravity(17);root.addView(title);
 TextView sub=new TextView(this);sub.setText("Your personal Android assistant");sub.setTextColor(Color.LTGRAY);sub.setGravity(17);root.addView(sub);
 input=new EditText(this);input.setSingleLine(true);input.setHint("Ask ORION something…");input.setTextColor(Color.WHITE);input.setHintTextColor(Color.GRAY);root.addView(input);
 Button ask=btn("Run command");root.addView(ask);ask.setOnClickListener(v->handle(input.getText().toString()));Button voice=btn("🎙 Speak");root.addView(voice);voice.setOnClickListener(v->listen());Button notes=btn("Show saved notes");root.addView(notes);notes.setOnClickListener(v->showNotes());output=new TextView(this);output.setTextColor(Color.WHITE);output.setTextSize(16);output.setPadding(0,22,0,0);root.addView(output,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);tts=new TextToSpeech(this,s->{});say("Ready. Try: help, battery, open example.com, remember buy milk, notes."); }
 Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
 void listen(){Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);try{startActivityForResult(i,SPEECH);}catch(Exception e){say("Speech recognition is unavailable.");}}
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==SPEECH&&c==RESULT_OK&&d!=null){ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty()){input.setText(a.get(0));handle(a.get(0));}}}
 void say(String s){output.setText(s);if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"orion");}
 void handle(String raw){String c=raw==null?"":raw.trim(),l=c.toLowerCase(Locale.ROOT);if(l.equals("help")){say("Commands: help, battery, open website, remember followed by a note, notes, clear notes.");}
 else if(l.equals("battery")){Intent b=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));int n=b==null?-1:b.getIntExtra("level",-1),scale=b==null?100:b.getIntExtra("scale",100);say(n<0?"Battery unavailable.":"Battery is at "+(n*100/Math.max(scale,1))+" percent.");}
 else if(l.startsWith("open ")){String u=c.substring(5).trim();if(!u.matches("(?i)^[a-z0-9.-]+(:[0-9]{1,5})?(/[^\\s]*)?$")||u.contains("..")){say("Use a valid website, such as example.com.");return;}if(!u.contains("://"))u="https://"+u;try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(u)));say("Opening "+u);}catch(Exception e){say("Could not open that website.");}}
 else if(l.startsWith("remember ")){String n=c.substring(9).trim();if(n.isEmpty()){say("Tell me what to remember.");return;}String old=prefs.getString("notes","");prefs.edit().putString("notes",old.isEmpty()?n:old+"\n"+n).apply();say("Saved your note.");}
 else if(l.equals("notes")){showNotes();}else if(l.equals("clear notes")){new AlertDialog.Builder(this).setTitle("Clear saved notes?").setMessage("This cannot be undone.").setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Clear",(d,w)->{prefs.edit().remove("notes").apply();say("Notes cleared.");}).show();}
 else say("I can handle basic commands locally. Try help. Online AI is not configured in this build.");}
 void showNotes(){String n=prefs.getString("notes","");say(n.isEmpty()?"You have no saved notes.":"Saved notes:\n"+n);}
 protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
