# ORION native Android app starter
Native Java app with Android speech recognition, TextToSpeech, battery status, URL opening and local notes.

## Build the APK
Upload these files to a GitHub repository, open Actions, run **Build ORION APK**, then download the `ORION-debug-apk` artifact from the completed workflow. Extract `app-debug.apk` and install it. This is a debug APK for testing, not a Play Store release.

This ZIP is source code, not an APK. Online speech recognition may need internet and a supported Android speech provider. No paid API or generative AI is configured. Broad control of other apps is not implemented.
